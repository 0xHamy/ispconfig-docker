
-- increase column size
ALTER TABLE `client` CHANGE `template_additional` `template_additional` TEXT NOT NULL;

