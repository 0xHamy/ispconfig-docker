-- --------------------------------------------------------

ALTER TABLE `web_domain` ADD `web_folder` VARCHAR( 100 ) DEFAULT NULL AFTER `document_root` ;


